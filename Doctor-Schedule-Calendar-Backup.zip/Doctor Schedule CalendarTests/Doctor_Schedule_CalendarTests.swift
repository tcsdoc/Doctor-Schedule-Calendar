//
//  Doctor_Schedule_CalendarTests.swift
//  Doctor Schedule CalendarTests
//
//  Created by mark on 7/5/25.
//

import Testing
@testable import Doctor_Schedule_Calendar

struct Doctor_Schedule_CalendarTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
